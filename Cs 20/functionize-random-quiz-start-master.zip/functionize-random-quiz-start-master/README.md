# functionize-random-quiz-start
Start Code for Functionize Random Quiz Example
